package com.cg.MainUI;

import java.util.Random;
import java.util.Scanner;

import com.cg.BankService.BankService;
import com.cg.BankService.IBankService;
import com.cg.Exception.BankException;
import com.cg.dto.AccountDetails;


public class MainUI
{
	AccountDetails ab=new AccountDetails();
	
	 Scanner sc=null;
  
	public static void main(String[] args)
	{
		 Scanner sc=null;
		 IBankService service=new BankService();
		 // AccountDetails ab=new AccountDetails();
		sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println(" ");
			System.out.println("****WELCOME****");
		System.out.println("Enter Your Choice");
		System.out.println("1. Create Account");
		System.out.println("2. Balance Enquiry ");
		System.out.println("3. Deposit balance");
		System.out.println("4. Withdraw Cash");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Mini statement");
		int a=0;
		a=sc.nextInt();
		switch(a)
		{
		case 1:
			Random ran=new Random();
			int accno=ran.nextInt(2000);
			System.out.println("Enter the Customer Name");
			String name=sc.next();
			boolean res1=service.validateCustomerName(name);
			try
			{
				if(res1==false)
				{
					throw new BankException("Invalid Name");
					}
					else {
						System.out.println("Continue");
					}
				{
			System.out.println("Enter the Branch");
			String branch=sc.next();
			boolean res2=service.ValidateBranch(branch);
			try
			{	
				if(res2==false)
				{
					throw new BankException("Invalid Branch Name");
					}
					else {
						System.out.println("Continue");
					}
					{
			System.out.println("Enter your Mobile No");
			String mobile=sc.next();
			boolean res3=service.ValidateCustomerMobileno(mobile);
			try
			{
				if(res3==false)
				{
					throw new BankException("Invalid Number");
					}
					else {
						System.out.println("Continue");
					}	
				{
			System.out.println("Enter The Account Balance");
			Double balance=sc.nextDouble();
			AccountDetails ab=new AccountDetails();
			service.addcustomer(accno,ab);
			System.out.println("****Success!!******");
			System.out.println("__Account Created Successfully__");
			System.out.println("Name: " +name);
			System.out.println("Branch: "+branch);
			System.out.println("Mobile No: "+mobile);
			System.out.println("Account number: " +accno);
			}}
			catch(Exception e)
			{
			System.out.println("Do not enter:"+e);
			}}}	
				catch (Exception e)
			{
					System.out.println("Do not Enter :"+e);	
			}			}	
			}
			catch (Exception e)
			{
				System.out.println("Do not Enter "+e);
			}
break;
		case 2:
		{	
			System.out.println("Enter Your Account Number To Get The Balance");
			int acc=sc.nextInt();
		AccountDetails ab=service.showbalance(acc);
		System.out.println(ab.getCustomerName()+ " Your Account Balance Is: "+ab.getAcc_Balance());
		}
		
		
		case 3:
		{
			System.out.println("Enter Your Account Number To Deposit");
			int acc=sc.nextInt();
			AccountDetails ab=service.showbalance(acc);
			double d=ab.getAcc_Balance();
			System.out.println("Your Account Balance is: "+d);
			System.out.println("Enter The Amount To Deposit");
			double amt=sc.nextDouble();
			double res=ab.setAcc_Balance(d+amt);
			System.out.println("Account Balance is: "+res);	
		}
		break;
	}
		}}}
