package com.cg.dto;

public class AccountDetails {

	private String CustomerName;
	
	private String MobileNo;
	private String BranchName;
	private double Acc_Balance;
	
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getBranchName() {
		return BranchName;
	}
	public void setBranchName(String branchName) {
		BranchName = branchName;
	}
	public double getAcc_Balance() {
		return Acc_Balance;
	}
	public double setAcc_Balance(double acc_Balance) {
		return Acc_Balance = acc_Balance;
	}
	public AccountDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountDetails(String customerName, String mobileNo, String branchName, double acc_Balance) {
		super();
		CustomerName = customerName;
		MobileNo = mobileNo;
		BranchName = branchName;
		Acc_Balance = acc_Balance;
	}
	@Override
	public String toString() {
		return "AccountDetails [CustomerName=" + CustomerName + ", MobileNo=" + MobileNo + ", BranchName=" + BranchName
				+ ", Acc_Balance=" + Acc_Balance + "]";
	}
}
