package com.cg.BankDAO;

import com.cg.dto.AccountDetails;

public interface IBankDAO {

	public int addcustomer(Integer a, AccountDetails a1);

}
