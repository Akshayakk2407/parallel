package com.cg.util;

import java.util.HashMap;


import com.cg.dto.AccountDetails;



	public class Collection {

		static HashMap<Integer, AccountDetails> hs=null;
		static {
			hs=new HashMap<Integer, AccountDetails>();
			hs.put(1234, new AccountDetails("YASH", "MIPL", "9840502059", 50000.00));
			hs.put(5678, new AccountDetails("SP", "TRC", "9840502069", 60000.00));
			hs.put(8765, new AccountDetails("THARUN", "SIPCOT", "9840502079", 70000.00));
			hs.put(4321, new AccountDetails("SANGEETH", "HOME", "9840502089", 80000.00));
}
		public static void addcustomer(Integer a, AccountDetails ab) {
			hs.put(a, ab); 
			
		}
		public static AccountDetails showbalance(int acc)
		{
			if(hs.containsKey(acc))
			{
				AccountDetails ab=hs.get(acc);
				return ab;
			}
			else
				return null;
		}
		
	}
